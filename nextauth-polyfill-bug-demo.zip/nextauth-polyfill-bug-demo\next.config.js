/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    fallbackNodePolyfills: false,
  },
};

module.exports = nextConfig;
